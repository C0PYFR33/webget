import os
from colorama import Fore
import time
import sys
def Banner():

    os.system("clear")
    
    print(Fore.LIGHTRED_EX+"""\n    
          _______  ______   _______  _______ _________
|\     /|(  ____ \(  ___ \ (  ____ \(  ____ \\__   __/
| )   ( || (    \/| (   ) )| (    \/| (    \/   ) (   
| | _ | || (__    | (__/ / | |      | (__       | |   
| |( )| ||  __)   |  __ (  | | ____ |  __)      | |   
| || || || (      | (  \ \ | | \_  )| (         | |   
| () () || (____/\| )___) )| (___) || (____/\   | |   
(_______)(_______/|/ \___/ (_______)(_______/   )_(   
                                                      
 ====================================================
 **              WebSite : iran123.org             **
 **              Channel : @iran123                **
 **             Developers : Amir Roox             **
 **           Team Members : :)))))))              **
 **               Thank's : .::Noob::.             **
 ====================================================         
          """)       
# ₿
def infolist1():
    time.sleep(0.1)
    print(Fore.RED+" ["+Fore.WHITE+"卐"+Fore.RED+"]"+Fore.CYAN+" Choose one of the options below \n")
    time.sleep(0.1)
    print(Fore.LIGHTYELLOW_EX+" [1] Information Gathering\n")
    time.sleep(0.1)
    print(Fore.RED+" [2] CMS Detection\n") 
    time.sleep(0.1)
    print(Fore.YELLOW+" [3] Developer :)\n")
    time.sleep(0.1)
    print(Fore.BLUE+" [4] Exit . . .\n")






def infolist2():
    time.sleep(0.1)
    print(Fore.GREEN+"  [1]"+Fore.BLUE+" - Bypass Cloud Flare")    
    print(Fore.CYAN+"  **********************") 
    time.sleep(0.2)

    print(Fore.GREEN+"  [2]"+Fore.BLUE+" - Cms Detect")   
    print(Fore.CYAN+"  **********************")
    time.sleep(0.1)

    print(Fore.GREEN+"  [3]"+Fore.BLUE+" - Trace Toute")   
    print(Fore.CYAN+"  **********************") 
    time.sleep(0.1)

    print(Fore.GREEN+"  [4]"+Fore.BLUE+" - Reverse IP")   
    print(Fore.CYAN+"  **********************") 
    time.sleep(0.1)

    print(Fore.GREEN+"  [5]"+Fore.BLUE+" - Port Scan")    
    print(Fore.CYAN+"  **********************") 
    time.sleep(0.1)

    print(Fore.GREEN+"  [6]"+Fore.BLUE+" - IP location Finder")
    print(Fore.CYAN+"  **********************") 
    time.sleep(0.1)

    print(Fore.GREEN+"  [7]"+Fore.BLUE+" - Show HTTP Header")    
    print(Fore.CYAN+"  **********************") 
    time.sleep(0.1)

    print(Fore.GREEN+"  [8]"+Fore.BLUE+" - Find Shared DNS")    
    print(Fore.CYAN+"  **********************") 
    time.sleep(0.1)

    print(Fore.GREEN+"  [9]"+Fore.BLUE+" - Whois")    
    print(Fore.CYAN+"  **********************")  
    time.sleep(0.1)

    print(Fore.GREEN+"  [10]"+Fore.BLUE+" - DNS Lookup")   
    print(Fore.CYAN+"  **********************")  
    time.sleep(0.1)

    print(Fore.GREEN+"  [11]"+Fore.BLUE+"- Robots Scanner")    
    print(Fore.CYAN+"  **********************")  
    time.sleep(0.1)

    print(Fore.GREEN+"  [12]"+Fore.BLUE+" - Admin Page Finder")    
    print(Fore.CYAN+"  **********************") 
    time.sleep(0.1)

    print(Fore.GREEN+"  [13]"+Fore.BLUE+" - Back To Menu")    
    print(Fore.CYAN+"  **********************")
    time.sleep(0.1)

    print(Fore.GREEN+"  [14]"+Fore.BLUE+" - Exit :) \n")   

def infolist3():

      
      Banner()
      time.sleep(0.1)
      print (Fore.GREEN+" [*]"+Fore.BLUE+"  Develper : Amir Roox :) \n")
      time.sleep(0.1)
      print (Fore.GREEN+" [*]"+Fore.GREEN+"  Thank's : .::Noob::.\n")
      time.sleep(0.1)
      print (Fore.GREEN+" [*]"+Fore.MAGENTA+"  My Site : www.iran123.org :)\n")
      time.sleep(0.1)
      print (Fore.GREEN+" [*]"+Fore.CYAN+"  ..... :]\n")
      time.sleep(0.1)
      try:

            input(Fore.LIGHTRED_EX+" [*]  Back To Menu (Press Enter...) ")
      except:
            print("")
            print("\n")
            sys.exit()

def infolist4():

    Banner()
    
    print(Fore.GREEN+"  [1]"+Fore.BLUE+"- WordPress ")    
    print(Fore.CYAN+"  **********************")  
    time.sleep(0.1)

    print(Fore.GREEN+"  [2]"+Fore.BLUE+" - Drupal"+Fore.RED+" Coming Soon . . .")    
    print(Fore.CYAN+"  **********************") 
    time.sleep(0.1)

    print(Fore.GREEN+"  [3]"+Fore.BLUE+" - Joomla "+Fore.RED+" Coming Soon . . . ")    
    print(Fore.CYAN+"  **********************")
    time.sleep(0.1)

    print(Fore.GREEN+"  [4]"+Fore.BLUE+" - Back To Menu")   
    
    print(Fore.CYAN+"  **********************\n")  
    time.sleep(0.1)


def infowp():
    Banner()
    
    print(Fore.GREEN+"  [1]"+Fore.BLUE+" - Get Plugins ")    
    print(Fore.CYAN+"  **********************")  
    time.sleep(0.1)

    print(Fore.GREEN+"  [2]"+Fore.BLUE+" - Get Username ")    
    print(Fore.CYAN+"  **********************")
    time.sleep(0.1)

    print(Fore.GREEN+"  [3]"+Fore.BLUE+" - Back To Menu ")

    print(Fore.CYAN+"  **********************\n")
    time.sleep(0.1)
