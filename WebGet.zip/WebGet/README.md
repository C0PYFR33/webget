
[![Python 3.5](https://img.shields.io/badge/Python-3.5-yellow.svg)](http://www.python.org/download/) 


# WEBGET V1

Tool Information Gathering Write With Python.


## PreView
<pre>

    
          _______  ______   _______  _______ _________
|\     /|(  ____ \(  ___ \ (  ____ \(  ____ \\__   __/
| )   ( || (    \/| (   ) )| (    \/| (    \/   ) (   
| | _ | || (__    | (__/ / | |      | (__       | |   
| |( )| ||  __)   |  __ (  | | ____ |  __)      | |   
| || || || (      | (  \ \ | | \_  )| (         | |   
| () () || (____/\| )___) )| (___) || (____/\   | |   
(_______)(_______/|/ \___/ (_______)(_______/   )_(   
                                                      
 ====================================================
 **              WebSite : iran123.org             **
 **              Channel : @iran123                **
 **             Developers : Amir Roox             **
 **           Team Members : :)))))))              **
 **               Thank's : .::Noob::.             **
 ====================================================          
          
 [卐] Choose one of the options below 

 [1] Information Gathering

 [2] CMS Detection

 [3] Developer :)

 [4] Exit . . .

 ┌─[WEBGET~@HOME]
 └──╼ 卐 


</pre>


## Operating Systems Tested
- Kali Linux 2020.1
- Windows 10
- Ubuntu 19.10


## Install
```bash
git clone https://github.com/C0PYFR33/WEBGET.git
cd WEBGET
pip install -r requirements.txt
python3 WEBGET.py 
```

## ScreenShot
![WEBGET]()

## Video Tutorial
Youtube : 


### Thanks to
    nothing ..... 

### Contact us
- WebSite iran123 : https://iran123.org

